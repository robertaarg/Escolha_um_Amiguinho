class PaginasController < ApplicationController
  def index
  end
end
