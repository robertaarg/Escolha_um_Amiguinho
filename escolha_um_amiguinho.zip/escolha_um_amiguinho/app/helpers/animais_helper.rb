module AnimaisHelper
end
