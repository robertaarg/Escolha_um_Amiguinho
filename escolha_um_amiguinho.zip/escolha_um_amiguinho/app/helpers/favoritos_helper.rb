module FavoritosHelper
end
