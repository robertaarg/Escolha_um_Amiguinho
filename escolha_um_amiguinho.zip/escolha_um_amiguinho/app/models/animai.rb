class Animai < ActiveRecord::Base
end
