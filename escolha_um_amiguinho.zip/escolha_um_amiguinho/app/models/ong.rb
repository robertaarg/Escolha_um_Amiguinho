class Ong < ActiveRecord::Base
end
