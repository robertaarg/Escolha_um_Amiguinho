class CreateOngs < ActiveRecord::Migration
  def change
    create_table :ongs do |t|
      t.string :nome
      t.string :telefone
      t.string :cnpj
      t.string :email
      t.string :cidade
      t.string :estado
      t.string :usuario
      t.string :senha

      t.timestamps null: false
    end
  end
end
