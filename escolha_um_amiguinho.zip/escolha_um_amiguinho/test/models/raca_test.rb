require 'test_helper'

class RacaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
